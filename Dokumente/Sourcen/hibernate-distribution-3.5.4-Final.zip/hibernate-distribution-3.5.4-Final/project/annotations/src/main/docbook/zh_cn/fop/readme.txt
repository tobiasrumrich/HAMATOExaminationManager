simhei.ttf has been removed as it's copyrighted.
simsun.ttf has been removed just in case.

TODO find open source fonts or migrate to jdocbook's system and list of fonts.