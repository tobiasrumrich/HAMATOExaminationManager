package org.hibernate.test.annotations.entity;

/**
 * @author Emmanuel Bernard
 */
public enum Starred {
	BAD,
	OK,
	GOOD
}
