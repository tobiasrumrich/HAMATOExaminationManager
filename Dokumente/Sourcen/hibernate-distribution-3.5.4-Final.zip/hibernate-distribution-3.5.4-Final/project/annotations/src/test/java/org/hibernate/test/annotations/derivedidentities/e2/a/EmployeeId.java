package org.hibernate.test.annotations.derivedidentities.e2.a;

import java.io.Serializable;

/**
 * @author Emmanuel Bernard
 */
public class EmployeeId implements Serializable {
	String  firstName;
	String lastName;
}
