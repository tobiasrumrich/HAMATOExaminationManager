package org.hibernate.test.annotations.derivedidentities.e5.b;

import java.io.Serializable;

/**
 * @author Emmanuel Bernard
 */
public class PersonId implements Serializable {
	String firstName;
	String lastName;
}
