package org.hibernate.test.annotations.collectionelement;

/**
 * @author Emmanuel Bernard
 */
public enum Character {
	GENTLE,
	NORMAL,
	AGGRESSIVE,
	ATTENTIVE,
	VIOLENT,
	CRAFTY
}
